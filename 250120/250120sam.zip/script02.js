let currentYear, birthYear, age;

currentYear = 2025;
birthYear = prompt("당신이 태어난 해는?", 2000);
age = currentYear - birthYear + 1;

console.log(typeof birthYear);
console.log(age);
