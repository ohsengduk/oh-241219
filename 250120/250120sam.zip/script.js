// const x = 10;
// const y = 4;

// let result;

// result = x / y;
// console.log(result);

// result = x % y;
// console.log(result);

// let a = 10;

// console.log(a);

// a = ++a;

// console.log(a);

// a = --a;

// console.log(a);

// let x = 10;
// let y = 4;
// let result;

// let x = 10,
//   y = 4,
//   result;

// result = x + --y;

// console.log(result);
// console.log(y);

// Garbage Collector = GC
// const actor = "현빈";
// const movie = "하얼빈";

// const result = actor + "님은 " + movie + "에 출연하였습니다!";

// const result = `${actor}님은 ${movie}에 출연하였습니다`;

// console.log(result);

// let x = 3,
//   y = 3;

// y = x + 3;
// y += x;
// y *= x;
// y %= x;
// console.log(y);

let str = "<table border='1'>";
str += "<tr>";
str += "<td>1</td><td>2</td><td>3</td>";
str += "</tr>";
str += "</table>";

document.write(str);

// console.log(3 == "3");
// console.log(3 === "3");

// console.log(3 != "3");
// console.log(3 !== "3");

// let a = 10,
//   b = 20;

// console.log(a > 10 || b > 20);
// console.log(a <= 10 || b > 20);
// console.log(a <= 10 && b > 20);

// let a = 10,
//   b = 3;

// let result = a < b ? "Javascript" : "Typescript";

// console.log(result);
